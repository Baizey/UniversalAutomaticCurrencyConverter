export {DeleteIcon} from './DeleteIcon'
export {ExchangeIcon} from './ExchangeIcon'
export {IconProps} from './IconProps'